multiscribe_intaller.vbs: a GPL'd VBScript file that runs on Win2000 through Vista to 
install/uninstall multiscribe to any directory.

To configure or learn more about it, edit multiscribe_installer.vbs by right mouse
clicking on it and selecting edit.
